from flask import Flask, jsonify
from flask_cors import CORS
import MetaTrader5 as mt5
import pandas as pd
from datetime import datetime
import json
import os

app = Flask(__name__)
CORS(app)

def get_market_data():
    """Baca data hasil scrape dari market-bulls.com"""
    default = {
        "cftc_net": 245678,
        "cftc_date": "01/06/26",
        "cme_max_pain": 4525
    }
    if os.path.exists('market_data.json'):
        try:
            with open('market_data.json', 'r') as f:
                return json.load(f)
        except:
            return default
    return default

@app.route('/api')
def get_data():
    # 1. AMBIL DATA MARKETBULLS
    market_data = get_market_data()
    
    # 2. AMBIL DATA MT5
    if not mt5.initialize():
        return jsonify({
            "error": "MT5 gagal konek. Pastiin MT5 kebuka & login",
            "price": 0,
            **market_data  # TETEP KIRIM DATA MARKETBULLS BIAR GA KOSONG
        })
    
    symbol_broker = "XAUUSDc"
    rates = mt5.copy_rates_from_pos(symbol_broker, mt5.TIMEFRAME_M15, 0, 100)
    
    if rates is None:
        mt5.shutdown()
        return jsonify({
            "error": f"Buka chart {symbol_broker} di MT5",
            "price": 0,
            **market_data
        })
        
    df = pd.DataFrame(rates)
    last_price = float(df.iloc[-1]['close'])
    
    ob_bullish = (df.iloc[-4]['close'] < df.iloc[-4]['open']) and (df.iloc[-1]['close'] > df.iloc[-4]['high'])
    near_prz = 4520 < last_price < 4545
    ema50 = float(df['close'].ewm(span=50).mean().iloc[-1])
    bias = "BULLISH" if last_price > ema50 else "BEARISH"
    
    # SIGNAL GENERATOR
    signal_status = "STANDBY"
    entry = sl = tp1 = tp2 = 0.0
    reason = "No confluence"
    
    if ob_bullish and near_prz and bias == "BULLISH":
        signal_status = "BUY"
        entry = round(last_price, 2)
        sl = round(entry - 15.0, 2)
        tp1 = round(entry + 15.0, 2)
        tp2 = round(entry + 30.0, 2)
        reason = "SMC + PRZ + EMA50 Confluence"
    elif bias == "BEARISH":
        signal_status = "SELL"
        entry = round(last_price, 2)
        sl = round(entry + 15.0, 2)
        tp1 = round(entry - 15.0, 2)
        tp2 = round(entry - 30.0, 2)
        reason = "EMA50 Bearish"
    
    mt5.shutdown()
    
    return jsonify({
        # DATA MT5 LIVE
        "price": round(last_price, 2),
        "cvd": int(df['tick_volume'].sum()),
        "bias": bias,
        "smc_active": int(ob_bullish),
        "prz_ready": int(near_prz),
        "smi": 68.5,
        "seasonal_bias": "NEUTRAL",
        "seasonal_month": "June",
        "seasonal_value": 1.75,
        "retail_long": 72,
        "retail_short": 28,
        "signal_status": signal_status,
        "entry": entry,
        "sl": sl,
        "tp1": tp1,
        "tp2": tp2,
        "reason": reason,
        "updated": datetime.now().strftime("%H:%M:%S"),
        "time": datetime.now().strftime("%H:%M:%S"),
        # DATA DARI MARKET-BULLS.COM
        "cftc_net": market_data.get("cftc_net", 0),
        "cftc_date": market_data.get("cftc_date", ""),
        "cme_max_pain": market_data.get("cme_max_pain", 4525),
        "error": None
    })

if __name__ == '__main__':
    print("==================================================")
    print("SERVER JALAN DI: http://localhost:5000/api")
    print("PASTIKAN market_data.json ADA DI FOLDER INI")
    print("==================================================")
    app.run(port=5000, debug=False)