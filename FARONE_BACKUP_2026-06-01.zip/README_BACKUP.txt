FARONE GOLD AI - BACKUP MENTAH

Tanggal Backup: 2026-06-01
Author: Setiawan F | Selviana R

ISI FILE:
1. main.py - Backend Flask + MT5 + MarketBulls
2. scrape_marketbulls.py - Scraper CFTC + Max Pain
3. market_data.json - Hasil scrape terakhir
4. index.html - Frontend Dashboard
5. requirements.txt - List library Python

CARA JALANIN:
1. pip install -r requirements.txt
2. python scrape_marketbulls.py
3. python main.py
4. Buka index.html

NOTE: Ganti API_URL di index.html ke ngrok kalo mau live di pages.dev
